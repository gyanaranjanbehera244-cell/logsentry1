@echo off
title LOGSENTRY - Live Public Cloudflare Tunnel
cd /d "%~dp0"

echo =====================================================================
echo               STARTING PUBLIC CLOUDFLARE TUNNEL                     
echo =====================================================================
echo.
echo Make sure LOGSENTRY is running (START_LOGSENTRY.bat).
echo Generating your instant public HTTPS URL...
echo.

"%USERPROFILE%\.local\bin\cloudflared.exe" tunnel --url http://127.0.0.1:8501

pause
