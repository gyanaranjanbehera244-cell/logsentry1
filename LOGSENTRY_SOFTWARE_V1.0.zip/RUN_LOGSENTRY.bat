@echo off
title LOGSENTRY Software v1.0
cd /d "%~dp0"

echo =====================================================================
echo                 LAUNCHING LOGSENTRY SOFTWARE v1.0                   
echo =====================================================================
echo.

if exist .venv\Scripts\streamlit.exe (
    echo [OK] Launching LOGSENTRY via virtual environment...
    start "" http://localhost:8501
    .\.venv\Scripts\streamlit.exe run app.py
) else (
    echo [*] Initializing python environment...
    if exist "%USERPROFILE%\.local\bin\uv.exe" (
        "%USERPROFILE%\.local\bin\uv.exe" venv .venv --python 3.11
        "%USERPROFILE%\.local\bin\uv.exe" pip install -r requirements.txt --python .venv\Scripts\python.exe
        start "" http://localhost:8501
        .\.venv\Scripts\streamlit.exe run app.py
    ) else (
        python -m pip install -r requirements.txt
        start "" http://localhost:8501
        python -m streamlit run app.py
    )
)
pause
