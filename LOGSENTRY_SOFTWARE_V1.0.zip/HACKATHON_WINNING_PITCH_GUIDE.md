# 🏆 LOGSENTRY — Hackathon Winning Pitch & Demo Cheat Sheet

This document contains everything you need to deliver an award-winning presentation to the hackathon judges.

---

## 🎯 30-Second Elevator Pitch
> *"Every organization generates gigabytes of security logs, but security analysts drown in alert fatigue while advanced attacks slip right through. **LOGSENTRY** is an autonomous, offline AI Security Operations Center. It correlates multi-stage attacks across the cyber kill chain in sub-second time, uses Explainable Isolation Forest to catch zero-day anomalies, maps threats directly to the MITRE ATT&CK framework, and generates instant one-click firewall containment scripts to stop attackers in their tracks."*

---

## ⏱️ 3-Minute Live Judge Demo Walkthrough

### Step 1: Open the Platform (0:00 - 0:30)
- Have **http://localhost:8501** open on full-screen.
- Point out the dark cyber SOC aesthetics:
  - *"Notice the DEFCON status indicator, real-time KPI metrics, and sub-second detection time."*
- Click **Clean Baseline** from the sidebar dropdown and click **Load Selected Scenario**:
  - *"First, notice false positive suppression: normal employee logins produce ZERO false alerts."*

### Step 2: Trigger the APT Multi-Stage Attack (0:30 - 1:30)
- In the sidebar, select **APT Multi-Stage Intrusion (Recommended)** and click **Load Selected Scenario**.
- Instantly point to the **Cyber Kill Chain progression cards**:
  - *"Watch the kill chain light up: Step 2 Credential Access (Brute Force) ➔ Step 3 Initial Access ➔ Step 4 Privilege Escalation ➔ Step 5 Crown Jewels DB Exfiltration."*
- Scroll to the **MITRE ATT&CK Matrix Navigator**:
  - Show how each stage maps to recognized industry standards: `T1110.001`, `T1078`, `T1098`, `T1530`.

### Step 3: Explainable AI & Machine Learning (1:30 - 2:15)
- Click **Tab 3: 🧠 Explainable AI / ML Lab**:
  - Show the 2D cluster scatter plot with the red anomaly dot.
  - Explain: *"We use an unsupervised Isolation Forest algorithm on multi-dimensional vectors (velocity, failure ratios, unique target accounts). Most importantly, we provide Explainable AI (XAI) that tells the analyst EXACTLY why the machine learning model flagged the IP."*

### Step 4: The Game-Changer — Automated SOAR Response (2:15 - 2:50)
- Click **Tab 4: ⚡ SOAR Automated Response**:
  - *"Most hackathon tools stop at detection. LOGSENTRY completes the loop with autonomous response."*
  - Toggle between **Linux iptables**, **Windows Defender Firewall**, and **AWS VPC ACL**.
  - Show the **Auto-Generated Sigma SIEM Rule (YAML)**:
    - *"This can be exported directly into enterprise SIEMs like Splunk, Sentinel, or Elastic."*

### Step 5: Wrap-up & Competitive Edge (2:50 - 3:00)
- *"LOGSENTRY runs completely offline and locally — keeping sensitive enterprise security telemetry safe from cloud leaks. Thank you, and we're ready for your questions!"*

---

## ❓ Tough Judge Questions & Winning Answers

| Judge Question | Your Winning Answer |
| :--- | :--- |
| **"Why not just use an existing SIEM like Splunk or Elastic?"** | *"Enterprise SIEMs cost hundreds of thousands of dollars, require cloud connectivity, and suffer from alert fatigue. LOGSENTRY is lightweight, runs locally without cloud dependencies, and combines unsupervised ML with automated 1-click SOAR remediation."* |
| **"Isn't Isolation Forest prone to high false positives?"** | *"That is precisely why we engineered a dual-engine architecture. Statistical ML is corroborated by temporal kill-chain correlation rules. Pure statistical noise without adversarial behavioral indicators is suppressed, as demonstrated in our Clean Baseline test."* |
| **"What formats does it support?"** | *"LOGSENTRY features an intelligent normalizer supporting standard/custom CSVs, Linux Syslog/auth.log, and Apache/Nginx web access logs with automatic column detection."* |
| **"Can it block attackers automatically in real time?"** | *"Yes. In addition to generating 1-click containment commands across Linux, Windows, AWS, and Cloudflare, the SOAR engine can be hooked into automated webhooks or local firewall agents."* |
