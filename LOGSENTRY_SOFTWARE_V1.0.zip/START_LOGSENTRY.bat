@echo off
title LOGSENTRY - Autonomous Cyber Defense SOC
cd /d "%~dp0LOGSENTRY_hackathon_starter\LOGSENTRY"

echo =====================================================================
echo               STARTING LOGSENTRY ENTERPRISE AI SOC                   
echo =====================================================================
echo.

if exist .venv\Scripts\streamlit.exe (
    echo [OK] Virtual environment detected. Launching LOGSENTRY...
    start "" http://localhost:8501
    .\.venv\Scripts\streamlit.exe run app.py --server.headless false
) else (
    echo [*] Setting up environment for first run...
    if exist "%USERPROFILE%\.local\bin\uv.exe" (
        "%USERPROFILE%\.local\bin\uv.exe" venv .venv --python 3.11
        "%USERPROFILE%\.local\bin\uv.exe" pip install -r requirements.txt --python .venv\Scripts\python.exe
        start "" http://localhost:8501
        .\.venv\Scripts\streamlit.exe run app.py
    ) else (
        echo [!] Falling back to standard python...
        python -m pip install -r requirements.txt
        start "" http://localhost:8501
        python -m streamlit run app.py
    )
)

pause
